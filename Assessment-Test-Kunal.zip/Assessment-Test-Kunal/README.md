# Bookstore API


# Solution Summary

The final solution includes:

- Dockerized FastAPI application
- PostgreSQL database container
- Docker Compose setup for local development
- Kubernetes manifests
- PostgreSQL StatefulSet
- Persistent storage
- ConfigMaps and Secrets
- Health probes
- Harbor private registry integration

---

# Improvements Implemented

## Containerization

The application was containerized using Docker.

Implemented:

- lightweight Python base image
- dependency isolation
- production-ready startup process
- Gunicorn + Uvicorn worker setup
- non-root container execution

---

## Multiple Container Deployment

The application was separated into multiple containers:

- FastAPI application
- PostgreSQL database

This provides proper dependency isolation and aligns with container best practices.

---

## Kubernetes Deployment

### FastAPI

Deployed using:

- Kubernetes Deployment
- Kubernetes Service

### PostgreSQL

Deployed using:

- StatefulSet
- Headless Service
- PersistentVolumeClaim

StatefulSet was selected because PostgreSQL is a stateful workload requiring:

- persistent storage
- stable networking
- ordered startup/shutdown

---

## Security Improvements

Implemented:

- non-root user execution
- Kubernetes Secrets
- resource requests and limits
- liveness probes
- readiness probes
- private registry authentication

---

## Database Initialization

Database schema and sample data initialization were automated using:

- initdb.sql
- PostgreSQL init hooks
- Kubernetes ConfigMap mounting

---

## Local Development Support

Docker Compose was implemented to support local development and testing without Kubernetes.

---

# Harbor Registry

Application image pushed to private Harbor registry:
- harbor.xyz.com/tooling/bookstore-api:v3


---

# Kubernetes Deployment

- Deployed All Resources



# Issues Identified in App and Resolved

## 1. Missing Python Dependencies

Application startup initially failed due to missing Python dependencies.

Resolution:

* validated and updated requirements.txt
* verified Docker dependency installation

---

## 2. JSON Serialization Error

Original Error:
    Object of type JSONResponse is not JSON serializable

Resolution:
- updated API response handling logic

---

## 3. Missing Health Endpoint

Original Error:
- HTTP probe failed with statuscode: 404

Resolution:
- added `/health` endpoint for Kubernetes probes

---

# Production Considerations - This can be also improve by following best practice

# Secrets Management:
For simplicity and easier evaluation, Kubernetes Secrets were used to store database credentials.

In a real production environment, a centralized secret-management solution would typically be preferred, such as:
    - AWS Secrets Manager
    - Azure Key Vault
    - External Secrets Operator etc.

# Database Initialization
For this assignment, database schema and sample data were initialized using:
- initdb.sql
- PostgreSQL init hooks
- Kubernetes ConfigMap mounting

This approach was selected to keep the deployment simple and reproducible for evaluation purposes.
In a production environment, database schema management would typically be handled using a migration tool such as:
- Flyway
- Alembic
- Liquibase

For simplicity and easier evaluation:
- kubectl port-forward
- NodePort service

were used during testing.

In a real production environment, preferred approaches would include:

- Ingress Controller
- LoadBalancer Service
- TLS/HTTPS
- DNS routing
- API Gateway

---

# Future Improvements

Potential production improvements:

- Helm charts
- CI/CD integration
- GitOps deployment
- Prometheus/Grafana monitoring
- centralized logging
- Vault/External Secrets integration
- PostgreSQL backups and replication
- Network Policies
- Horizontal Pod Autoscaler

---

# Final Result
# Validation Screenshots
- Deployment validation screenshots are available in the screenshots/ directory.

The application was successfully:
- containerized
- deployed to Kubernetes
- connected to PostgreSQL
- configured with persistent storage
- secured using non-root containers
- integrated with Harbor registry
- configured with health checks
- tested successfully

Both:

- Docker Compose deployment
- Kubernetes deployment

were validated successfully.

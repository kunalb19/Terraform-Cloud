import psycopg2
from psycopg2 import extras, sql

DEFAULT_FIELDS = ("name", "year", "author")


def connect(database, host, user, password, port):
    conn = psycopg2.connect(
        database=database,
        host=host,
        user=user,
        password=password,
        port=port,
    )
    return conn


def query_db(
    conn,
    schema,
    table,
    select_fields=DEFAULT_FIELDS,
    name=None,
    year=None,
    author=None,
    limit=100,
):
    with conn.cursor(cursor_factory=extras.DictCursor) as cur:
        query = sql.Composed(
            [
                sql.SQL("SELECT "),
                sql.SQL(", ").join(
                    sql.Identifier(field)
                    for field in select_fields
                ),
                sql.SQL(" FROM "),
                sql.Identifier(schema),
                sql.SQL("."),
                sql.Identifier(table),
                sql.SQL(" WHERE "),
                sql.Identifier("name"),
                sql.SQL("="),
                sql.SQL("COALESCE(%s, name) "),
                sql.SQL("AND "),
                sql.Identifier("year"),
                sql.SQL("="),
                sql.SQL("COALESCE(%s, year) "),
                sql.SQL("AND "),
                sql.Identifier("author"),
                sql.SQL("="),
                sql.SQL("COALESCE(%s, author) "),
                sql.SQL("LIMIT "),
                sql.Literal(limit),
            ]
        )

        cur.execute(query, (name, year, author))
        result = cur.fetchall()

    return [dict(row) for row in result]
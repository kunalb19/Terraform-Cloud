import logging

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from .config import settings
from .db import connect, query_db

logging.basicConfig(level=logging.INFO)

app = FastAPI()


@app.get("/")
async def root():
    return {"message": "Welcome to the bookstore!"}


@app.get("/health")
async def health():
    return {"status": "healthy"}


@app.get("/book/")
async def book(
    name: str = None,
    year: int = None,
    author: str = None,
    limit: int = 100,
):
    conn = None

    try:
        conn = connect(
            database=settings.database,
            host=settings.host,
            port=settings.port,
            user=settings.user,
            password=settings.password,
        )

        result = query_db(
            conn,
            settings.db_schema,
            "book",
            ("name", "author", "year"),
            name=name,
            year=year,
            author=author,
            limit=limit,
        )

        return JSONResponse(content=result)

    except Exception:
        logging.exception("Database query failed")

        return JSONResponse(
            {"message": "Internal server error"},
            status_code=500,
        )

    finally:
        if conn:
            conn.close()


@app.get("/db_info/")
def db_info():
    conn = None

    try:
        conn = connect(
            database=settings.database,
            host=settings.host,
            port=settings.port,
            user=settings.user,
            password=settings.password,
        )

        return {
            "message": (
                f"Connected to "
                f"{settings.host}:{settings.port}/"
                f"{settings.database}. "
                f"User: {settings.user}."
            )
        }

    except Exception:
        logging.exception("Database connection failed")

        return JSONResponse(
            {"message": "Database connection failed"},
            status_code=500,
        )

    finally:
        if conn:
            conn.close()